# Description

This resource will set the value for the app domain settings at the farm level.
You can set the domain name and the prefix that is to be used for app URLs.
